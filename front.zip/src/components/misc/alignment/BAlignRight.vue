<template>
  <b-row align-h="between">
    <b-col cols="auto" />
    <b-col cols="auto">
      <slot />
    </b-col>
  </b-row>
</template>

<script>
  export default {
    name: "BAlignRight"
  }
</script>

<style scoped>

</style>
