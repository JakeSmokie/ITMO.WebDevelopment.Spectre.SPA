export class RaceOnPlanetEntity {
  constructor(raceId = 0, race = "", level = 0) {
    this.raceId = raceId;
    this.race = race;
    this.level = level;
  }
}
